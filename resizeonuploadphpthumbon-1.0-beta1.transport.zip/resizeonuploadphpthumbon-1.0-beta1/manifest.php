<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a98f0a4ed330059f0c7ee3bacbaf1cc6',
      'native_key' => 'resizeonuploadphpthumbon',
      'filename' => 'modNamespace/1567dbc4496efbc735918d5fe7d0e10c.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'bdb2d27c42e8f63911f68e2af02e65a6',
      'native_key' => 36,
      'filename' => 'modPlugin/4c303f300b70df8a1920b4e5307bb5a0.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6da9c6800c24135626e82e5265025ae2',
      'native_key' => 1,
      'filename' => 'modCategory/9488448d44a1d04c62be58da1bea8abd.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'afdaf893088ea87e80ea5060ade69272',
      'native_key' => 'afdaf893088ea87e80ea5060ade69272',
      'filename' => 'xPDOTransportVehicle/d259b8100cf731f52989119563ee7e0c.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
  ),
);