<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '78ec9e4c8bd1a32aaeaaaa0e38e00579',
      'native_key' => 'resizeonuploadphpthumbon',
      'filename' => 'modNamespace/198e691200e21a805b0957f172b075bc.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '510af71e26126189ebd4a8ade13fc32a',
      'native_key' => 14,
      'filename' => 'modPlugin/5cc6fd5353e504e5cd3912c956594be2.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bdbe723cd1c2245d5c9c0ade0d1a0cd2',
      'native_key' => 1,
      'filename' => 'modCategory/4611e1d7d05b5e199581240634175371.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
  ),
);