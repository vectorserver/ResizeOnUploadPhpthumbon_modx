<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a36d631d0848ecf463c6aa9199a8f4e4',
      'native_key' => 'resizeonuploadphpthumbon',
      'filename' => 'modNamespace/02ae910a9d2ad68b6e6426756c46b4e4.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '05bcb2e2233f0a85593a765f4241ee90',
      'native_key' => 14,
      'filename' => 'modPlugin/75472ccd60a0e2abc77d06c9e9fc2b48.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3effcbc0da111c41cc8c0971c695f36b',
      'native_key' => 1,
      'filename' => 'modCategory/0cb90d635ca12b23fe77f17b7b9dde2e.vehicle',
      'namespace' => 'resizeonuploadphpthumbon',
    ),
  ),
);